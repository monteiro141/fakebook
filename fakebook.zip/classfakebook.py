# -*- coding: utf-8 -*-
"""
Created on Thu Dec  9 16:37:47 2021

@author: User
"""
from class_fanatic import fanatic
from class_self import Self_centered
from class_naive import naive

class Fakebook:
    def __init__(self):
        self.user = {}
    
    def get_user(self):
        return self.user

    def has_user(self,userid):
        #return userid in self.user
        if userid not in self.user.keys():
            return False
        else:
            return True
    
    
    def register(self,userkind,userid):
        if userkind == "selfcentered":
            self.user[userid] = Self_centered(userkind,userid)
            return True
        elif userkind == "naive":
            self.user[userid] = naive(userkind,userid)
            return True
        elif userkind == "fanatic":
            fanaticUser = fanatic(userkind,userid)
            if fanaticUser.class_sequenceOfFanaticisms():
                self.user[userid] = fanaticUser
                return True
        return False
    
    def users(self):
        sorted_user = sorted(self.user.items())
        for key, value in sorted_user:
            value.class_printUser()


    def has_friend(self,first_userid,second_userid):
        return self.user[first_userid].class_has_friend(second_userid)
    
    def add_friend(self,first_userid,second_userid):
        self.user[first_userid].class_add_friend(second_userid)
        self.user[second_userid].class_add_friend(first_userid)
            
    def friends(self,first_userid):
        return self.user[first_userid].class_friends()
            
    def post_hashtags(self,userid, sequence_of_hashtags):
        for i in range(0,len(sequence_of_hashtags)):
            if sequence_of_hashtags[i] in sequence_of_hashtags[i+1:]:
                return False
        return True
    
    def post_honest_fake(self,userid,sequence_of_hashtags,truthfulness):
        return self.user[userid].class_post_honest_fake(userid,sequence_of_hashtags,truthfulness)

    def create_post(self,userid,sequence_of_hashtags,truthfulness,message):
        self.user[userid].class_create_post(userid,sequence_of_hashtags,truthfulness,message)
        
    def number_posts(self,userid):
        return self.user[userid].class_number_posts()

    def comment_fanaticism(self,positiveNegative,comment,userComment, numberOfPost, userPost):
        fanatic = self.user[userPost].posts[numberOfPost-1]['truthfulness']
        sequence_of_hashtags = self.user[userPost].posts[numberOfPost-1]['sequence_of_hashtags']
        return self.user[userComment].class_comment_fanaticism(positiveNegative,comment,userComment, numberOfPost, userPost, fanatic,sequence_of_hashtags,self.user[userPost].posts[numberOfPost-1])

    def add_comment(self,positiveNegative,comment,userComment,userPost,numberOfPost):
        self.user[userComment].class_add_comment(positiveNegative,comment,userComment,userPost,numberOfPost)
        self.user[userPost].class_add_comment_to_post(positiveNegative,comment,userComment,userPost,numberOfPost)
    
    def show_posts(self,userid,postid):
        return self.user[userid].class_show_posts(postid)
        
        
            
        